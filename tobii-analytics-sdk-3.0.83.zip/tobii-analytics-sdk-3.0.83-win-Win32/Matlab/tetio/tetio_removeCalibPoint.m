function matrix = tetio_removeCalibPoint(x, y)
	tetio_matlab('tetio_removeCalibPoint', x, y);
end
