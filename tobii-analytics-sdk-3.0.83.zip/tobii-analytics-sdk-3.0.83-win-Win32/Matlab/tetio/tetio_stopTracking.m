function tetio_stopTracking()
	tetio_matlab('tetio_stopTracking');
end
