function time = tetio_localTimeNow()
	time = tetio_matlab('tetio_localTimeNow');
end