function synced = tetio_clockSyncState()
	synced = tetio_matlab('tetio_clockSyncState');
end