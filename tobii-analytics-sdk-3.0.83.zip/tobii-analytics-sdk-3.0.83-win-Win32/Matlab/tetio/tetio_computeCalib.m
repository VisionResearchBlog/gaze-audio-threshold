function tetio_computeCalib()
	tetio_matlab('tetio_computeCalib');
end
