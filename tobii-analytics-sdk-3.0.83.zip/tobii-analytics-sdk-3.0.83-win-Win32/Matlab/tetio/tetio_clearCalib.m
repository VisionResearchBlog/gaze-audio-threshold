function tetio_clearCalib()
	tetio_matlab('tetio_clearCalib');
end
