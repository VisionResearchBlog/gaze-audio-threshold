Eye Tracker Browser 
----------------------------
This program find eye trackers on the network, connect to a specific eye tracker, perform a calibration and subscribe to data from the eye tracker.  

Running the Eye Tracker Browser application
-----------------------------
Windows (Win32 or x64)
1. You need Bonjour installed.
     - A Bonjour installer is bundled with the SDK in the directory  "Bonjour"
	 - Install it by running the .msi file.
2. Run the application

	 
Ubuntu 10.04
1. You need libssh2
     - Install it with sudo apt-get install libssh2-1-dev
2. You need QT libraries, 
     - Install it with sudo apt-get install qt4-dev-tools
3. Run the application

Mac OS X
TODO...
